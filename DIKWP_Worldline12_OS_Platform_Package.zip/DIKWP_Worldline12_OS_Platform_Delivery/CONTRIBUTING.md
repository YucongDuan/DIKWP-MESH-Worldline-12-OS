# Contributing

贡献一个Forecast时须同时提交：

1. 唯一ID、基准日和结算日；
2. 二元或明确可判定的 statement；
3. prior probability 与 confidence；
4. resolution rule 和结算来源；
5. 至少一个反向Trigger；
6. observer、purpose、context 与Residual；
7. Action Hedge 与Kill条件；
8. 对应JSON Schema测试。

不接受无法结算的“趋势判断”、没有时间窗的断言、以历史类比代替机制的预测，或把主观政治偏好伪装成概率的提交。
