#!/usr/bin/env python3
"""Local HTTP gateway for DIKWP MESH Worldline-12 OS.

This reference gateway uses only Python's standard library. It is suitable for
local demonstration and controlled research. It is not hardened for public or
production deployment.
"""
from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any
from urllib.parse import parse_qs, urlparse

from worldline12_runtime import (
    accident_surface_score,
    get_forecast,
    load_registry,
    make_update,
    resolve_forecast,
)


def cadence_from_score(score: float) -> str:
    if score >= 0.80:
        return "daily_or_event_triggered"
    if score >= 0.65:
        return "twice_weekly"
    if score >= 0.45:
        return "weekly"
    return "monthly"


class WorldlineHandler(BaseHTTPRequestHandler):
    server_version = "Worldline12Gateway/0.1"

    def _json(self, status: int, payload: Any) -> None:
        body = json.dumps(payload, ensure_ascii=False, indent=2).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _read_json(self) -> dict:
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError as exc:
            raise ValueError("invalid Content-Length") from exc
        if length <= 0:
            return {}
        raw = self.rfile.read(length)
        try:
            obj = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ValueError("request body must be valid UTF-8 JSON") from exc
        if not isinstance(obj, dict):
            raise ValueError("request body must be a JSON object")
        return obj

    def _segments(self) -> list[str]:
        return [part for part in urlparse(self.path).path.split("/") if part]

    def do_GET(self) -> None:  # noqa: N802
        try:
            parsed = urlparse(self.path)
            segments = [part for part in parsed.path.split("/") if part]
            if segments == ["health"]:
                self._json(HTTPStatus.OK, {
                    "status": "ok",
                    "runtime": "DIKWP MESH Worldline-12 OS",
                    "as_of": datetime.now(timezone.utc).isoformat(),
                })
                return
            if segments == ["forecasts"]:
                registry = load_registry()
                domain = parse_qs(parsed.query).get("domain", [None])[0]
                items = registry["forecasts"]
                if domain:
                    items = [item for item in items if item.get("domain", "").casefold() == domain.casefold()]
                self._json(HTTPStatus.OK, items)
                return
            if len(segments) == 2 and segments[0] == "forecasts":
                self._json(HTTPStatus.OK, get_forecast(segments[1]))
                return
            self._json(HTTPStatus.NOT_FOUND, {"error": "endpoint not found"})
        except KeyError as exc:
            self._json(HTTPStatus.NOT_FOUND, {"error": str(exc)})
        except Exception as exc:  # local demo boundary
            self._json(HTTPStatus.INTERNAL_SERVER_ERROR, {"error": str(exc)})

    def do_POST(self) -> None:  # noqa: N802
        try:
            segments = self._segments()
            body = self._read_json()
            if segments == ["accident-surface", "evaluate"]:
                required = [
                    "actor_concentration", "coupling_density", "time_pressure", "opacity",
                    "symbolic_salience", "redundancy", "irreversibility", "calendar_density",
                ]
                missing = [key for key in required if key not in body]
                if missing:
                    raise ValueError(f"missing fields: {', '.join(missing)}")
                score = accident_surface_score(*(float(body[key]) for key in required))
                self._json(HTTPStatus.OK, {"score": round(score, 6), "cadence": cadence_from_score(score)})
                return
            if len(segments) == 3 and segments[0] == "forecasts" and segments[2] == "updates":
                ratios = body.get("likelihood_ratios")
                if not isinstance(ratios, list) or not ratios:
                    raise ValueError("likelihood_ratios must be a non-empty array")
                update = make_update(
                    segments[1],
                    [float(value) for value in ratios],
                    evidence=body.get("evidence") or [],
                    observer=str(body.get("observer") or "default-analyst"),
                    purpose=str(body.get("purpose") or "12-month calibrated forecasting"),
                    residuals=body.get("residuals") or None,
                )
                self._json(HTTPStatus.OK, update)
                return
            if len(segments) == 3 and segments[0] == "forecasts" and segments[2] == "resolve":
                if "final_probability" not in body or "outcome" not in body or "sources" not in body:
                    raise ValueError("final_probability, outcome and sources are required")
                if not isinstance(body["sources"], list):
                    raise ValueError("sources must be an array")
                result = resolve_forecast(
                    segments[1],
                    float(body["final_probability"]),
                    bool(body["outcome"]),
                    [str(item) for item in body["sources"]],
                )
                self._json(HTTPStatus.OK, result)
                return
            self._json(HTTPStatus.NOT_FOUND, {"error": "endpoint not found"})
        except KeyError as exc:
            self._json(HTTPStatus.NOT_FOUND, {"error": str(exc)})
        except (TypeError, ValueError) as exc:
            self._json(HTTPStatus.BAD_REQUEST, {"error": str(exc)})
        except Exception as exc:  # local demo boundary
            self._json(HTTPStatus.INTERNAL_SERVER_ERROR, {"error": str(exc)})

    def log_message(self, fmt: str, *args: object) -> None:
        print(f"[worldline12] {self.address_string()} - {fmt % args}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the local Worldline-12 reference gateway")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8792)
    args = parser.parse_args()
    server = ThreadingHTTPServer((args.host, args.port), WorldlineHandler)
    print(f"Worldline-12 gateway listening on http://{args.host}:{args.port}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
