#!/usr/bin/env python3
"""DIKWP MESH Worldline-12 OS deterministic reference runtime.

The runtime does not guarantee contingent history. It enforces:
- resolvable forecast cards,
- time-stamped probability updates,
- observer/purpose indexing,
- accident-surface monitoring,
- explicit resolution and calibration.
"""
from __future__ import annotations

import argparse
import json
import math
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable, Sequence

BASE = Path(__file__).resolve().parents[1]
REGISTRY_PATH = BASE / "data" / "forecast_registry.json"


def _clip_probability(p: float, eps: float = 1e-9) -> float:
    if not isinstance(p, (int, float)) or not math.isfinite(float(p)):
        raise ValueError("probability must be a finite number")
    return min(1.0 - eps, max(eps, float(p)))


def odds(p: float) -> float:
    p = _clip_probability(p)
    return p / (1.0 - p)


def probability_from_odds(o: float) -> float:
    if not isinstance(o, (int, float)) or not math.isfinite(float(o)) or o < 0:
        raise ValueError("odds must be a finite non-negative number")
    return float(o) / (1.0 + float(o))


def update_probability(prior: float, likelihood_ratios: Sequence[float]) -> float:
    current_odds = odds(prior)
    for lr in likelihood_ratios:
        if not isinstance(lr, (int, float)) or not math.isfinite(float(lr)) or lr <= 0:
            raise ValueError("likelihood ratios must be finite and greater than zero")
        current_odds *= float(lr)
    return probability_from_odds(current_odds)


def brier_score(probability: float, outcome: bool | int) -> float:
    p = _clip_probability(probability, eps=0)
    y = 1.0 if bool(outcome) else 0.0
    return (p - y) ** 2


def log_score(probability: float, outcome: bool | int) -> float:
    p = _clip_probability(probability)
    return -math.log(p if bool(outcome) else 1.0 - p)


def accident_surface_score(
    actor_concentration: float,
    coupling_density: float,
    time_pressure: float,
    opacity: float,
    symbolic_salience: float,
    redundancy: float,
    irreversibility: float,
    calendar_density: float,
) -> float:
    vals = [actor_concentration, coupling_density, time_pressure, opacity,
            symbolic_salience, redundancy, irreversibility, calendar_density]
    if any((not isinstance(v, (int, float)) or not math.isfinite(float(v)) or float(v) < 0 or float(v) > 1) for v in vals):
        raise ValueError("all accident-surface inputs must be finite values in [0,1]")
    weights = [0.16, 0.16, 0.14, 0.12, 0.10, 0.12, 0.12, 0.08]
    transformed = [actor_concentration, coupling_density, time_pressure, opacity,
                   symbolic_salience, 1.0 - redundancy, irreversibility, calendar_density]
    return min(1.0, max(0.0, sum(w * float(v) for w, v in zip(weights, transformed))))


def decision_band(probability: float, accident_score: float = 0.0) -> str:
    p = _clip_probability(probability, eps=0)
    a = min(1.0, max(0.0, float(accident_score)))
    if a >= 0.80:
        return "ESCALATE_REVIEW_AND_REHEARSE"
    if p >= 0.85:
        return "HEDGE_PREPARE"
    if p >= 0.65:
        return "MONITOR_WITH_TRIGGERS"
    if p >= 0.35:
        return "KEEP_LIVE_BRANCHES"
    if p >= 0.15:
        return "LOW_PROBABILITY_CONTINGENCY"
    return "WATCH_ONLY"


def load_registry(path: Path = REGISTRY_PATH) -> dict:
    with open(path, encoding="utf-8") as handle:
        obj = json.load(handle)
    if "forecasts" not in obj:
        raise ValueError("forecast registry has no forecasts array")
    return obj


def get_forecast(forecast_id: str, registry: dict | None = None) -> dict:
    registry = registry or load_registry()
    for item in registry["forecasts"]:
        if item["id"] == forecast_id:
            return item
    raise KeyError(f"forecast not found: {forecast_id}")


def make_update(
    forecast_id: str,
    likelihood_ratios: Sequence[float],
    evidence: Sequence[str] | None = None,
    observer: str = "default-analyst",
    purpose: str = "12-month calibrated forecasting",
    residuals: Sequence[str] | None = None,
    registry: dict | None = None,
) -> dict:
    forecast = get_forecast(forecast_id, registry)
    prior = float(forecast["probability"])
    posterior = update_probability(prior, likelihood_ratios)
    ts = datetime.now(timezone.utc)
    return {
        "update_id": f"UPD-{forecast_id}-{ts.strftime('%Y%m%dT%H%M%S.%f%z')}",
        "forecast_id": forecast_id,
        "timestamp": ts.isoformat(),
        "prior": round(prior, 6),
        "likelihood_ratios": [float(x) for x in likelihood_ratios],
        "posterior": round(posterior, 6),
        "evidence": list(evidence or []),
        "observer": observer,
        "purpose": purpose,
        "residuals": list(residuals or ["Likelihood ratios are analyst inputs and require independent review."]),
    }


def resolve_forecast(forecast_id: str, final_probability: float, outcome: bool, sources: Sequence[str]) -> dict:
    forecast = get_forecast(forecast_id)
    return {
        "forecast_id": forecast_id,
        "resolved_at": datetime.now(timezone.utc).isoformat(),
        "outcome": "YES" if outcome else "NO",
        "final_probability": round(float(final_probability), 6),
        "brier_score": round(brier_score(final_probability, outcome), 6),
        "log_score": round(log_score(final_probability, outcome), 6),
        "resolution_rule": forecast["resolution_rule"],
        "sources": list(sources),
        "status": "RESOLVED",
    }


def replay_bundle(forecast_id: str, updates: Sequence[dict], accident_surface: dict | None = None) -> dict:
    forecast = get_forecast(forecast_id)
    return {
        "runtime": "DIKWP MESH Worldline-12 OS",
        "as_of": datetime.now(timezone.utc).isoformat(),
        "forecast": forecast,
        "updates": list(updates),
        "accident_surface": accident_surface or {},
        "semantic_contract": {
            "lexical_anchor": forecast["anchor"],
            "observer": "registered analyst or affected planner",
            "purpose": forecast["action"],
            "context": f"2026-07-18 to {forecast['resolution_date']}",
            "allowed_output": ["probability", "trigger", "branch", "residual", "action hedge"],
            "forbidden_output": ["guaranteed contingent outcome", "personalized financial or political manipulation advice"],
        },
    }


def _cmd_list(args: argparse.Namespace) -> None:
    registry = load_registry()
    rows = sorted(registry["forecasts"], key=lambda x: x["probability"], reverse=True)
    for f in rows:
        print(f"{f['id']}  {f['probability']:.0%}  {f['domain']:<24} {f['statement']}")


def _cmd_update(args: argparse.Namespace) -> None:
    update = make_update(args.forecast, args.lr, args.evidence, args.observer, args.purpose)
    f = get_forecast(args.forecast)
    accident = args.accident if args.accident is not None else 0.0
    print(json.dumps({"forecast": f, "update": update, "decision": decision_band(update["posterior"], accident)}, ensure_ascii=False, indent=2))


def _cmd_demo(args: argparse.Namespace) -> None:
    update = make_update("F03", [0.70, 1.25], [
        "Tanker insurance remains elevated.",
        "Alternative-route investment increases medium-term normalization odds."
    ])
    accident = accident_surface_score(0.85, 0.90, 0.85, 0.72, 0.88, 0.30, 0.92, 0.78)
    bundle = replay_bundle("F03", [update], {"score": round(accident, 6), "label": "Hormuz"})
    bundle["decision"] = decision_band(update["posterior"], accident)
    print(json.dumps(bundle, ensure_ascii=False, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser(description="Worldline-12 deterministic reference runtime")
    sub = parser.add_subparsers(dest="command", required=True)
    p_list = sub.add_parser("list", help="list forecast cards")
    p_list.set_defaults(func=_cmd_list)
    p_update = sub.add_parser("update", help="apply reviewed likelihood ratios")
    p_update.add_argument("--forecast", required=True)
    p_update.add_argument("--lr", type=float, nargs="+", required=True)
    p_update.add_argument("--evidence", action="append", default=[])
    p_update.add_argument("--observer", default="default-analyst")
    p_update.add_argument("--purpose", default="12-month calibrated forecasting")
    p_update.add_argument("--accident", type=float)
    p_update.set_defaults(func=_cmd_update)
    p_demo = sub.add_parser("demo", help="run a sample Hormuz update")
    p_demo.set_defaults(func=_cmd_demo)
    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
