import unittest

from worldline12_gateway import cadence_from_score


class GatewayTests(unittest.TestCase):
    def test_cadence(self):
        self.assertEqual(cadence_from_score(0.85), "daily_or_event_triggered")
        self.assertEqual(cadence_from_score(0.70), "twice_weekly")
        self.assertEqual(cadence_from_score(0.50), "weekly")
        self.assertEqual(cadence_from_score(0.20), "monthly")


if __name__ == "__main__":
    unittest.main()
