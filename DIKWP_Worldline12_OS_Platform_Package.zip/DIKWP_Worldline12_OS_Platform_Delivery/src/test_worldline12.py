import json
import math
import unittest
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import worldline12_runtime as wr

class Worldline12Tests(unittest.TestCase):
    def test_odds_roundtrip(self):
        for p in (0.1, 0.5, 0.9):
            self.assertAlmostEqual(wr.probability_from_odds(wr.odds(p)), p)

    def test_update_neutral(self):
        self.assertAlmostEqual(wr.update_probability(0.64, [1.0, 1.0]), 0.64)

    def test_update_direction(self):
        self.assertGreater(wr.update_probability(0.5, [2.0]), 0.5)
        self.assertLess(wr.update_probability(0.5, [0.5]), 0.5)

    def test_brier(self):
        self.assertAlmostEqual(wr.brier_score(0.7, True), 0.09)

    def test_accident_surface(self):
        score = wr.accident_surface_score(.85,.90,.85,.72,.88,.30,.92,.78)
        self.assertGreater(score, 0.8)
        self.assertLessEqual(score, 1)

    def test_registry_and_update(self):
        f = wr.get_forecast("F03")
        self.assertEqual(f["domain"], "Middle East")
        u = wr.make_update("F03", [0.7,1.25])
        self.assertTrue(0 < u["posterior"] < 1)

    def test_resolution(self):
        r = wr.resolve_forecast("F01", 0.79, True, ["S01"])
        self.assertEqual(r["outcome"], "YES")
        self.assertAlmostEqual(r["brier_score"], (0.79-1)**2)

if __name__ == "__main__":
    unittest.main()
