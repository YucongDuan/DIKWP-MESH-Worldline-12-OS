# Source Ledger

Snapshot date: 2026-07-18. Sources must be refreshed when a role, rule, conflict or forecast changes.

- **S01 — World Economic Outlook Update, July 2026** (IMF, 2026-07-08). Global growth, war and technology baseline. https://www.imf.org/en/publications/weo/issues/2026/07/08/world-economic-outlook-update-july-2026
- **S02 — Economic Outlook, Volume 2026 Issue 1** (OECD, 2026-06-03). Growth scenarios, energy shock and country outlooks. https://www.oecd.org/en/publications/oecd-economic-outlook-volume-2026-issue-1_2d1956f0-en.html
- **S03 — Global Trade Update: Invisible barriers** (UNCTAD, 2026-05). Non-tariff barriers and trade fragmentation. https://unctad.org/publication/global-trade-update-may-2026-invisible-barriers-costs-non-tariff-measures
- **S04 — Global Trade Update: Critical minerals** (UNCTAD, 2026-06). Critical-mineral trade restrictions. https://unctad.org/publication/global-trade-update-june-2026-shifting-dynamics-critical-minerals-trade
- **S05 — Iran renews attacks on Gulf states after another night of US strikes** (Reuters, 2026-07-18). Current U.S.-Iran war and civilian/infrastructure damage. https://www.reuters.com/world/middle-east/iran-renews-attacks-gulf-states-after-another-night-us-strikes-2026-07-18/
- **S06 — Iran expands attacks after declaring Strait of Hormuz closed** (Reuters, 2026-07-11). Hormuz closure and Gulf escalation. https://www.reuters.com/world/asia-pacific/iran-declares-strait-hormuz-closed-unauthorised-vessel-hit-2026-07-11/
- **S07 — US and Iran exchange strikes as they struggle over Strait of Hormuz** (Associated Press, 2026-07). Independent conflict and maritime corroboration. https://apnews.com/article/5adfef67554652580963684d9a663af2
- **S08 — Putin likely to escalate Ukraine war despite peace push** (Reuters, 2026-07-09). Current war persistence and negotiation posture. https://www.reuters.com/world/europe/putin-likely-escalate-ukraine-war-despite-trump-peace-push-sources-say-2026-07-09/
- **S09 — Ukraine and Russia at War News** (Reuters, 2026-07). Ongoing strike and negotiation updates. https://www.reuters.com/world/ukraine-crisis/
- **S10 — 2026 Congressional Primary Dates and Candidate Filing Deadlines** (U.S. Federal Election Commission, 2026-05-18). U.S. general election date. https://www.fec.gov/resources/cms-content/documents/2026pdates.pdf
- **S11 — Current Senators and Party Division** (U.S. Senate, 2026-07). Senate baseline. https://www.senate.gov/senators/
- **S12 — 2026 House Ratings** (Sabato’s Crystal Ball, 2026-07-16). House seat environment. https://centerforpolitics.org/crystalball/2026-house/
- **S13 — 2026 Senate Ratings** (Sabato’s Crystal Ball, 2026-06-11). Senate seat environment. https://centerforpolitics.org/crystalball/2026-senate/
- **S14 — Americans expect prolonged U.S.-Iran war** (Reuters/Ipsos, 2026-07-13). U.S. opinion and election pressure. https://www.reuters.com/world/us/americans-expect-prolonged-us-iran-war-ceasefire-falters-reutersipsos-poll-finds-2026-07-13/
- **S15 — 2026 Brazilian election calendar** (Brazil Superior Electoral Court, 2026). Brazil election dates. https://www.tse.jus.br/eleicoes/calendario-eleitoral
- **S16 — Dates of the next elections** (French Public Service, 2026-07-01). France presidential election dates. https://www.service-public.fr/particuliers/vosdroits/F1939?lang=en
- **S17 — AI Act regulatory framework** (European Commission, 2026-07-07). AI Act application timeline and transparency rules. https://digital-strategy.ec.europa.eu/en/policies/regulatory-framework-ai
- **S18 — Code of Practice on marking and labelling AI-generated content** (European Commission, 2026-06-10). Article 50 transparency implementation. https://digital-strategy.ec.europa.eu/en/news/commission-publishes-code-practice-marking-and-labelling-ai-generated-content
- **S19 — Energy demand from AI** (International Energy Agency, 2025/2026). Data-centre and AI electricity projections. https://www.iea.org/reports/energy-and-ai/energy-demand-from-ai
- **S20 — Key Questions on Energy and AI: Executive summary** (International Energy Agency, 2026). Updated data-centre electricity baseline. https://www.iea.org/reports/key-questions-on-energy-and-ai/executive-summary
- **S21 — ENSO Diagnostic Discussion** (NOAA Climate Prediction Center, 2026-07-09). El Nino forecast. https://www.cpc.ncep.noaa.gov/products/analysis_monitoring/enso_advisory/ensodisc.shtml
- **S22 — El Nino forecast to intensify** (World Meteorological Organization, 2026). Extreme-weather implications. https://wmo.int/news/media-centre/el-nino-forecast-intensify-increasing-likelihood-of-extreme-weather
- **S23 — 2026 Atlantic hurricane season outlook** (NOAA, 2026). Season activity prior. https://www.noaa.gov/news-release/noaa-predicts-below-normal-2026-atlantic-hurricane-season
- **S24 — More global temperature records ahead** (World Meteorological Organization, 2026). 2026-2030 temperature probabilities. https://wmo.int/news/media-centre/new-report-suggests-more-global-temperature-records-ahead
- **S25 — Ebola outbreak situation page** (World Health Organization, 2026). Current outbreak monitoring. https://www.who.int/emergencies/situations/ebola-outbreak---drc-2026
- **S26 — Ebola Disease Outbreak News DON613** (World Health Organization, 2026). Case, control and transmission updates. https://www.who.int/emergencies/disease-outbreak-news/item/2026-DON613
- **S27 — World Economic Outlook database and China forecast references** (IMF, 2026). China growth cross-check. https://www.imf.org/en/Publications/WEO
- **S28 — 2025 China Military Power Report** (U.S. Department of Defense, 2025-12-23). PLA capability and 2027 goal context. https://media.defense.gov/2025/Dec/23/2003849070/-1/-1/1/ANNUAL-REPORT-TO-CONGRESS-MILITARY-AND-SECURITY-DEVELOPMENTS-INVOLVING-THE-PEOPLES-REPUBLIC-OF-CHINA-2025.PDF
- **S29 — U.S.-Japan-ROK Trilateral Foreign Ministers Meeting** (U.S. Department of State, 2026-07). Regional concern about Taiwan coercion. https://www.state.gov/releases/office-of-the-spokesperson/2026/07/united-states-japan-republic-of-korea-rok-trilateral-foreign-ministers-meeting
- **S30 — Defining Life: A Conversation** (Kofman et al., 2026). Observer-relative thresholds, morphospace and residual discipline. https://doi.org/10.13133/2532-5876/19492
