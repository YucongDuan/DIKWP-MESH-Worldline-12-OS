# Resolution Record

- Forecast ID:
- Resolution date:
- Outcome: YES / NO / VOID
- Frozen resolution rule:
- Sources used:
- Final probability:
- Brier score:
- Log score:
- Ambiguities:
- Auditor decision:
- Calibration lesson:
