# Forecast Update Ticket

- Update ID:
- Forecast ID:
- Timestamp:
- Prior:
- New evidence:
- Source and measurement status:
- Likelihood ratio(s):
- Posterior:
- Observer:
- Purpose:
- Residuals / dependence warning:
- Decision:
- Reviewer:
