# Accident Surface Card

Score each 0-1 and explain the evidence:
- Actor concentration:
- Coupling density:
- Time pressure:
- Opacity:
- Symbolic salience:
- Redundancy:
- Irreversibility:
- Calendar density:
- Resulting update cadence:
- Contingency depth:
- Kill conditions:
