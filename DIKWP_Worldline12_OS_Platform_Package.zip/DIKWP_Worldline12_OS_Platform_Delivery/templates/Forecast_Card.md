# Forecast Card

- Forecast ID:
- Lexical anchor (query handle only):
- Observer / boundary:
- Purpose:
- As-of date:
- Resolution date:
- Resolvable statement:
- Prior probability:
- Forecast class:
- Structural drivers:
- Calendar locks:
- Trigger signals and likelihood ratios:
- Resolution rule:
- Counterevidence:
- Residuals:
- Robust action:
- Kill conditions:
