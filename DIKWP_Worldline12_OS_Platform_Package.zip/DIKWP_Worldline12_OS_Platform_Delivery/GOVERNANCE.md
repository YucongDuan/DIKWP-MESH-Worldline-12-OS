# Governance

Worldline-12 的发布与更新采用职责分离：

- **Forecast Architect**：编写可结算问题、阈值和预测窗口；不得单独结算自己的预测。
- **Source Steward**：核验时效来源、当前职位、日期、法规和数据版本。
- **Domain Reviewer**：审查领域机制、反例与Residual。
- **Calibration Lead**：维护概率更新、Brier/Log Score与校准曲线。
- **Affected-Party Reviewer**：审查行动建议的成本、权利和不可逆后果。
- **Governance Board**：处理Kill、争议、用途越界与公开更正。

Forecast 的概率变化必须保留 prior、likelihood ratios、evidence、observer、purpose、residuals 和时间戳。不得静默改写历史概率。结算必须依据预注册的 resolution rule 和来源。
